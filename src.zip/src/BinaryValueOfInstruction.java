import static utils.Utils.convertBinaryValueToFitRightNumberOfBits;

public class BinaryValueOfInstruction {

    public String getFullBinaryOfUniqueInstruction(String instructionOperator, String[] instructionOperands) throws Exception {
        String instructionOperatorName = instructionOperator.toUpperCase();
        UniqueInstructionName uniqueInstructionName = UniqueInstructionName.valueOf(instructionOperatorName);
        return switch (uniqueInstructionName) {
            case LSLS_SASM -> lslsSASM(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case LSRS_SASM -> lsrsSASM(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case ASRS_SASM -> asrsSASM(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case ADDS_REGISTER -> addsRegister(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case SUBS_REGISTER -> subsRegister(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case ADDS_IMMEDIATE ->
                    addsImmediate(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case SUBS_IMMEDIATE ->
                    subsImmediate(instructionOperands[0], instructionOperands[1], instructionOperands[2]);
            case MOVS -> movs(instructionOperands[0], instructionOperands[1]);
            case CMP_SASM -> cmpSAMS(instructionOperands[0], instructionOperands[1]);
            case ADDS_OPTIONAL -> addsOptional(instructionOperands[0], instructionOperands[1]);
            case SUBS_OPTIONAL -> subsOptional(instructionOperands[0], instructionOperands[1]);
            case ANDS -> ands(instructionOperands[0], instructionOperands[1]);
            case EORS -> eors(instructionOperands[0], instructionOperands[1]);
            case LSLS_DP -> lslsDP(instructionOperands[0], instructionOperands[1]);
            case LSRS_DP -> lsrsDP(instructionOperands[0], instructionOperands[1]);
            case ASRS_DP -> asrsDP(instructionOperands[0], instructionOperands[1]);
            case ADCS -> adcs(instructionOperands[0], instructionOperands[1]);
            case SBCS -> sbcs(instructionOperands[0], instructionOperands[1]);
            case RORS -> rors(instructionOperands[0], instructionOperands[1]);
            case TST -> tst(instructionOperands[0], instructionOperands[1]);
            case RSBS -> rsbs(instructionOperands[0], instructionOperands[1]);
            case CMP_DP -> cmpDP(instructionOperands[0], instructionOperands[1]);
            case CMN -> cmn(instructionOperands[0], instructionOperands[1]);
            case ORRS -> orrs(instructionOperands[0], instructionOperands[1]);
            case MULS -> muls(instructionOperands[0], instructionOperands[1]);
            case BICS -> bics(instructionOperands[0], instructionOperands[1]);
            case MVNS -> mvns(instructionOperands[0], instructionOperands[1]);
            case STR ->
                    str(instructionOperands[0], InstructionArgumentsDetection.getStrOrLdrNecessaryArguments(instructionOperands));
            // ldr
            // add
            // sub
            default -> "";
        };
    }

    public String getFullBinaryOfBranchingInstruction(String instructionOperator, int destLineNumber, int srcLineNumber) throws Exception {
        String instructionOperatorName = instructionOperator.toUpperCase();
        int immediate8or11 = destLineNumber - srcLineNumber - 3;
        if (BranchingInstructionName.UnconditionalInstructionName.isUnconditional(instructionOperatorName).isPresent()) {
            return unconditional(String.valueOf(immediate8or11));
        }
        BranchingInstructionName.ConditionalInstructionName branchingInstructionName =
                BranchingInstructionName.ConditionalInstructionName.valueOf(instructionOperatorName);
        return switch (branchingInstructionName) {
            case BEQ, BNE, BCS, BHS, BCC, BLO, BMI, BPL, BVS, BVC, BHI,
                    BLS, BGE, BLT, BGT, BLE, BAL ->
                    conditional(branchingInstructionName, String.valueOf(immediate8or11));
        };
    }

    private String conditional(BranchingInstructionName.ConditionalInstructionName name, String imm8) throws Exception {
        String imm8ToBinary = Integer.toBinaryString(Integer.parseInt(imm8));
        return name.instructionConstantKnownValue + convertImmediateToCorrectNumberOfBits(imm8ToBinary, 8);
    }

    private String unconditional(String imm11) throws Exception {
        String imm11ToBinary = Integer.toBinaryString(Integer.parseInt(imm11));
        return BranchingInstructionName.UnconditionalInstructionName.B.instructionConstantKnownValue +
                convertImmediateToCorrectNumberOfBits(imm11ToBinary, 11);
    }

    // immediate substring 1 -> to avoid the "#"
    // register substring 1 -> to avoid the "r"

    private String lslsSASM(String rd, String rm, String imm5) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));
        String imm5ToBinary = Integer.toBinaryString(Integer.parseInt(imm5.substring(1)));

        return UniqueInstructionName.LSLS_SASM.instructionConstantKnownValue +
                convertImmediateToCorrectNumberOfBits(imm5ToBinary, 5) +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String lsrsSASM(String rd, String rm, String imm5) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));
        String imm5ToBinary = Integer.toBinaryString(Integer.parseInt(imm5.substring(1)));

        return UniqueInstructionName.LSRS_SASM.instructionConstantKnownValue +
                convertImmediateToCorrectNumberOfBits(imm5ToBinary, 5) +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String asrsSASM(String rd, String rm, String imm5) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));
        String imm5ToBinary = Integer.toBinaryString(Integer.parseInt(imm5.substring(1)));

        return UniqueInstructionName.ASRS_SASM.instructionConstantKnownValue +
                convertImmediateToCorrectNumberOfBits(imm5ToBinary, 5) +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String addsRegister(String rd, String rn, String rm) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.ADDS_REGISTER.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String subsRegister(String rd, String rn, String rm) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.SUBS_REGISTER.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String addsImmediate(String rd, String rn, String imm3) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String imm3ToBinary = Integer.toBinaryString(Integer.parseInt(imm3.substring(1)));

        return UniqueInstructionName.ADDS_IMMEDIATE.instructionConstantKnownValue +
                convertImmediateToCorrectNumberOfBits(imm3ToBinary, 3) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String subsImmediate(String rd, String rn, String imm3) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String imm3ToBinary = Integer.toBinaryString(Integer.parseInt(imm3.substring(1)));

        return UniqueInstructionName.SUBS_IMMEDIATE.instructionConstantKnownValue +
                convertImmediateToCorrectNumberOfBits(imm3ToBinary, 3) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String movs(String rd, String imm8) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String imm8ToBinary = Integer.toBinaryString(Integer.parseInt(imm8.substring(1)));

        return UniqueInstructionName.MOVS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary) +
                convertImmediateToCorrectNumberOfBits(imm8ToBinary, 8);
    }

    private String cmpSAMS(String rd, String imm8) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String imm8ToBinary = Integer.toBinaryString(Integer.parseInt(imm8.substring(1)));

        return UniqueInstructionName.CMP_SASM.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary) +
                convertImmediateToCorrectNumberOfBits(imm8ToBinary, 8);
    }

    private String addsOptional(String rdn, String imm8) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String imm8ToBinary = Integer.toBinaryString(Integer.parseInt(imm8.substring(1)));

        return UniqueInstructionName.ADDS_OPTIONAL.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary) +
                convertImmediateToCorrectNumberOfBits(imm8ToBinary, 8);
    }

    private String subsOptional(String rdn, String imm8) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String imm8ToBinary = Integer.toBinaryString(Integer.parseInt(imm8.substring(1)));

        return UniqueInstructionName.SUBS_OPTIONAL.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary) +
                convertImmediateToCorrectNumberOfBits(imm8ToBinary, 8);
    }

    private String ands(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.ANDS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String eors(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.EORS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String lslsDP(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.LSLS_DP.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String lsrsDP(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.LSRS_DP.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String asrsDP(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.ASRS_DP.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String adcs(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.ADCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String sbcs(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String rors(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.RORS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String tst(String rn, String rm) throws Exception {
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary);
    }

    private String rsbs(String rd, String rn) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String cmpDP(String rn, String rm) throws Exception {
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.CMP_DP.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary);
    }

    private String cmn(String rn, String rm) throws Exception {
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.CMN.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary);
    }

    private String orrs(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String muls(String rdm, String rn) throws Exception {
        String rdmToBinary = Integer.toBinaryString(Integer.parseInt(rdm.substring(1)));
        String rnToBinary = Integer.toBinaryString(Integer.parseInt(rn.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rnToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdmToBinary);
    }

    private String bics(String rdn, String rm) throws Exception {
        String rdnToBinary = Integer.toBinaryString(Integer.parseInt(rdn.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdnToBinary);
    }

    private String mvns(String rd, String rm) throws Exception {
        String rdToBinary = Integer.toBinaryString(Integer.parseInt(rd.substring(1)));
        String rmToBinary = Integer.toBinaryString(Integer.parseInt(rm.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rmToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(rdToBinary);
    }

    private String str(String rt, String imm8) throws Exception {
        String rtToBinary = Integer.toBinaryString(Integer.parseInt(rt.substring(1)));
        if (imm8.isBlank()) {
            return UniqueInstructionName.STR.instructionConstantKnownValue +
                    convertRegisterNumberToCorrectNumberOfBits(rtToBinary) +
                    "00000000";
        }
        String imm8ToBinary = Integer.toBinaryString(Integer.parseInt(imm8.substring(1)));

        return UniqueInstructionName.SBCS.instructionConstantKnownValue +
                convertRegisterNumberToCorrectNumberOfBits(rtToBinary) +
                convertRegisterNumberToCorrectNumberOfBits(imm8ToBinary);
    }

    private String convertImmediateToCorrectNumberOfBits(String immediateBinaryString, int maxSizeOfBinaryValue) throws Exception {
        double maxValue = Math.pow(2, maxSizeOfBinaryValue - (double) 1);
        double maxPossiblePositiveValue = maxValue - 1;
        double minPossibleNegativeValue = -1 * maxValue;
        int immediateAsInteger = Integer.parseInt(immediateBinaryString, 2);

        if (immediateAsInteger > maxPossiblePositiveValue || immediateAsInteger < minPossibleNegativeValue) {
            throw new Exception("The immediate has a value exceeding " + maxPossiblePositiveValue + " or inferior at " + minPossibleNegativeValue);
        }
        return convertBinaryValueToFitRightNumberOfBits(immediateBinaryString, maxSizeOfBinaryValue);
    }

    private String convertRegisterNumberToCorrectNumberOfBits(String registerNumber) throws Exception {
        double maxPossiblePositiveValue = 7;
        double minPossibleNegativeValue = 0;
        int registerNumberAsInteger = Integer.parseInt(registerNumber, 2);
        if (registerNumberAsInteger > maxPossiblePositiveValue || registerNumberAsInteger < minPossibleNegativeValue) {
            throw new Exception("The register number has a value exceeding " + maxPossiblePositiveValue + " or inferior at " + minPossibleNegativeValue);
        }
        return convertBinaryValueToFitRightNumberOfBits(registerNumber, 3);
    }

}
