public class InstructionArgumentsDetection {

    // This class is made to detect arguments of instructions having optional arguments,
    // in order to know what to give to methods determining binary value

    // So, for now, it is for : STR, LDR, ADD and SUB instructions

    // MAYBE IT WILL NOT WORK FOR LDR
    public static String getStrOrLdrNecessaryArguments(String[] instructionOperands) throws Exception {
        if (instructionOperands.length == 1) return "#0";
        else if (instructionOperands.length == 3) {
            if (instructionOperands[2].charAt(0) == '#') {
                return instructionOperands[2];
            } else {
                throw new Exception("str or ldr mal formée");
            }
        } else {
            throw new Exception("str or ldr mal formée");
        }
    }

    public static String getAddOrSubNecessaryArgument(String[] instructionOperands) throws Exception {
        if (instructionOperands.length == 2 && instructionOperands[1].charAt(0) == '#') {
            return instructionOperands[1];
        } else if (instructionOperands.length == 3 && instructionOperands[2].charAt(0) == '#') {
            return instructionOperands[2];
        } else {
            throw new Exception("add or sub mal formée");
        }
    }
}
