package IO;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class Input {

    public static void readFile(String filename) {

        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] allPartsOfInstruction = getAllPartsOfInstruction(line);
                String lineOperator = allPartsOfInstruction[0];
                String[] lineOperands = Arrays.copyOfRange(allPartsOfInstruction, 1, allPartsOfInstruction.length);

                // do something to detect which operation and what to do with operands
            }
        } catch (Exception x) {
            x.printStackTrace();
        }
    }


    public static String[] getAllPartsOfInstruction(String line) {
        String string = line.replace(",", " ");
        return Arrays.stream(string.split(" "))
                .filter(value -> value != null && value.length() > 0)
                .toArray(String[]::new);
    }
}
