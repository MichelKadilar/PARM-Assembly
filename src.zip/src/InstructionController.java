import java.util.Arrays;
import java.util.Optional;

import static IO.Input.getAllPartsOfInstruction;

public class InstructionController {

    public static void addLabelsForfirstParcoursForLabels(String instruction, int currentLineNumber) throws Exception {
        Optional<String> potentialLabel = LabelDetection.detectLabel(instruction);
        if (potentialLabel.isPresent()) {
            if (LabelDetection.lineNumberAndAssociatedLabelOfInstruction.containsKey(potentialLabel.get())) {
                throw new Exception("Rencontre d'un label qui existe déjà, ce qui n'est pas possible");
            }
            LabelDetection.addLabel(currentLineNumber, potentialLabel.get());
        } /*else {
            throw new Exception("Rencontre de quelque chose qui n'est ni une instruction, ni un label...");
        }*/
    }

    public static String getInstructionBinaryResult(String instruction, int currentLineNumber) throws Exception {
        // if not a label then
        Optional<String> potentialLabel = LabelDetection.detectLabel(instruction);
        if (potentialLabel.isPresent()) {
            return potentialLabel.get();
        } else {
            String[] allPartsOfInstruction = getAllPartsOfInstruction(instruction);
            String instructionOperator = allPartsOfInstruction[0];
            String[] instructionOperands = Arrays.copyOfRange(allPartsOfInstruction, 1, allPartsOfInstruction.length);

            BinaryValueOfInstruction binaryValueOfInstruction = new BinaryValueOfInstruction();
            Optional<UniqueInstructionName> potentialUniqueInstruction = UniqueInstructionName.getUniqueInstructionIfParameterIsUniqueInstruction(instructionOperator);
            if (potentialUniqueInstruction.isPresent()) {
                return binaryValueOfInstruction.getFullBinaryOfUniqueInstruction(potentialUniqueInstruction.get().name(), instructionOperands);
            }
            Optional<DuplicateInstructionName> duplicateInstructionName = DuplicateInstructionName.isInstructionDuplicate(instructionOperator);
            if (duplicateInstructionName.isPresent()) {
                UniqueInstructionName uniqueInstructionName = DuplicateInstructionName.transformDuplicateInstructionNameToUniqueInstructionName(duplicateInstructionName.get(), instructionOperands);
                if (uniqueInstructionName != null) {
                    return binaryValueOfInstruction.getFullBinaryOfUniqueInstruction(uniqueInstructionName.name(), instructionOperands);
                } else {
                    throw new Exception("an instruction name :" + instructionOperator + "doesn't exist");
                }
            }
            Optional<BranchingInstructionName.ConditionalInstructionName> conditionalInstructionName = BranchingInstructionName.ConditionalInstructionName.isConditional(instructionOperator);
            if (conditionalInstructionName.isPresent()) {
                return binaryValueOfInstruction.getFullBinaryOfBranchingInstruction(conditionalInstructionName.get().name(),
                        LabelDetection.lineNumberAndAssociatedLabelOfInstruction.get(instructionOperands[0]), currentLineNumber);
            }
            Optional<BranchingInstructionName.UnconditionalInstructionName> unconditionalInstructionName = BranchingInstructionName.UnconditionalInstructionName.isUnconditional(instructionOperator);
            if (unconditionalInstructionName.isPresent()) {
                return binaryValueOfInstruction.getFullBinaryOfBranchingInstruction(unconditionalInstructionName.get().name(),
                        LabelDetection.lineNumberAndAssociatedLabelOfInstruction.get(instructionOperands[0]), currentLineNumber);
            } else {
                throw new Exception(instruction + " does not correspond to any of the existant instructions");
            }
        }
    }
}
