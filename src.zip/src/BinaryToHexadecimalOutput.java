public class BinaryToHexadecimalOutput {

    private static String output;
    private static int numberOfInstructionsAdded = 1; // beggining to 1 so we can be more coherent in the treatement

    public static void addInstruction(String binaryValueOfInstruction) {
        output += convertBinaryValueOfInstructionToHexadecimal(binaryValueOfInstruction);
        numberOfInstructionsAdded++;
        if (numberOfInstructionsAdded % 16 == 0) {
            output += "\n";
        } else {
            output += " ";
        }
    }

    public static String convertBinaryValueOfInstructionToHexadecimal(String binaryValueOfInstruction) {
        int nbOfBits = 16;
        String res = "";
        String tmp4bitsValue = "";
        for (int i = 0; i < nbOfBits; i++) {
            tmp4bitsValue += binaryValueOfInstruction.charAt(i);
            if ((i + 1) % 4 == 0) {
                int decimalValue = Integer.parseInt(tmp4bitsValue, 2);
                res += Integer.toHexString(decimalValue);
                tmp4bitsValue = "";
            }
        }
        return res;
    }

    public static String getOutput() {
        return output;
    }
}
