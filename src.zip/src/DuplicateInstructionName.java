import java.util.Optional;

import static utils.Utils.argumentsContains;

public enum DuplicateInstructionName {
    LSLS, LSRS, ASRS, ADDS, SUBS, CMP;

    public static Optional<DuplicateInstructionName> isInstructionDuplicate(String instructionOperator) {
        for (DuplicateInstructionName duplicateInstructionName : values()) {
            if (instructionOperator.toUpperCase().equals(duplicateInstructionName.name()))
                return Optional.of(duplicateInstructionName);
        }
        return Optional.empty();
    }

    public static UniqueInstructionName transformDuplicateInstructionNameToUniqueInstructionName(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        return switch (duplicateInstructionName) {
            case LSLS -> transformDuplicateLSLStoUniqueLSLS(duplicateInstructionName, instructionOperands);
            case LSRS -> transformDuplicateLSRStoUniqueLSRS(duplicateInstructionName, instructionOperands);
            case ASRS -> transformDuplicateASRStoUniqueASRS(duplicateInstructionName, instructionOperands);
            case ADDS -> transformDuplicateADDStoUniqueADDS(duplicateInstructionName, instructionOperands);
            case SUBS -> transformDuplicateSUBStoUniqueSUBS(duplicateInstructionName, instructionOperands);
            case CMP -> transformDuplicateCMPtoUniqueCMP(duplicateInstructionName, instructionOperands);
        };
    }

    private static UniqueInstructionName transformDuplicateLSLStoUniqueLSLS(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        if (duplicateInstructionName.name().equals(LSLS.name())) {
            if (argumentsContains("#", instructionOperands)) {
                return UniqueInstructionName.LSLS_SASM;
            } else {
                return UniqueInstructionName.LSLS_DP;
            }
        }
        return null;
    }

    private static UniqueInstructionName transformDuplicateLSRStoUniqueLSRS(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        if (duplicateInstructionName.name().equals(LSRS.name())) {
            if (argumentsContains("#", instructionOperands)) {
                return UniqueInstructionName.LSRS_SASM;
            } else {
                return UniqueInstructionName.LSRS_DP;
            }
        }
        return null;
    }

    private static UniqueInstructionName transformDuplicateASRStoUniqueASRS(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        if (duplicateInstructionName.name().equals(ASRS.name())) {
            if (argumentsContains("#", instructionOperands)) {
                return UniqueInstructionName.ASRS_SASM;
            } else {
                return UniqueInstructionName.ASRS_DP;
            }
        }
        return null;
    }

    private static UniqueInstructionName transformDuplicateADDStoUniqueADDS(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        if (duplicateInstructionName.name().equals(ADDS.name())) {
            if ((argumentsContains("[", instructionOperands) &&
                    argumentsContains("]", instructionOperands) && instructionOperands.length == 3)
                    ||
                    (instructionOperands.length == 2 && argumentsContains("#", instructionOperands))) {
                return UniqueInstructionName.ADDS_OPTIONAL;
            } else if (argumentsContains("#", instructionOperands) && instructionOperands.length == 3) {
                return UniqueInstructionName.ADDS_IMMEDIATE;
            } else {
                return UniqueInstructionName.ADDS_REGISTER;
            }
        }
        return null;
    }

    private static UniqueInstructionName transformDuplicateSUBStoUniqueSUBS(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        if (duplicateInstructionName.name().equals(SUBS.name())) {
            if ((argumentsContains("[", instructionOperands) &&
                    argumentsContains("]", instructionOperands) && instructionOperands.length == 3)
                    ||
                    (instructionOperands.length == 2 && argumentsContains("#", instructionOperands))) {
                return UniqueInstructionName.SUBS_OPTIONAL;
            } else if (argumentsContains("#", instructionOperands) && instructionOperands.length == 3) {
                return UniqueInstructionName.SUBS_IMMEDIATE;
            } else {
                return UniqueInstructionName.SUBS_REGISTER;
            }
        }
        return null;
    }

    private static UniqueInstructionName transformDuplicateCMPtoUniqueCMP(DuplicateInstructionName duplicateInstructionName, String[] instructionOperands) {
        if (duplicateInstructionName.name().equals(CMP.name())) {
            if (argumentsContains("#", instructionOperands)) {
                return UniqueInstructionName.CMP_SASM;
            } else {
                return UniqueInstructionName.CMP_DP;
            }
        }
        return null;
    }
}
