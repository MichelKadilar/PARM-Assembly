import java.util.Optional;

public class BranchingInstructionName {

    public enum ConditionalInstructionName {
        BEQ("0000"),
        BNE("0001"),
        BCS("0010"),
        BHS(BCS.instructionConstantKnownValue),
        BCC("0011"),
        BLO(BCC.instructionConstantKnownValue),
        BMI("0100"),
        BPL("0101"),
        BVS("0110"),
        BVC("0111"),
        BHI("1000"),
        BLS("1001"),
        BGE("1010"),
        BLT("1011"),
        BGT("1100"),
        BLE("1101"),
        BAL("1110");

        // Maybe add the always false conditional enum


        final String instructionConstantKnownValue;

        ConditionalInstructionName(String contantKnownValue) {
            this.instructionConstantKnownValue = "1101" + contantKnownValue;
        }

        public static Optional<ConditionalInstructionName> isConditional(String instructionOperator) {
            for (ConditionalInstructionName c : values()) {
                if (c.name().equals(instructionOperator.toUpperCase())) {
                    return Optional.of(c);
                }
            }
            return Optional.empty();
        }
    }

    public enum UnconditionalInstructionName {
        B("11100");

        final String instructionConstantKnownValue;

        UnconditionalInstructionName(String constantKnownValue) {
            this.instructionConstantKnownValue = constantKnownValue;
        }

        public static Optional<UnconditionalInstructionName> isUnconditional(String instructionOperator) {
            return B.name().equals(instructionOperator.toUpperCase()) ?
                    Optional.of(B) : Optional.empty();
        }
    }


}
