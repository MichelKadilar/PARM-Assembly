import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Optional;

public class Main {

    public static void main(String[] args) throws Exception {

        /*System.out.println(BinaryToHexadecimalOutput.convertBinaryValueOfInstructionToHexadecimal(
                InstructionController.getInstructionBinaryResult("movs r0, #4", 0)));*/


        //System.out.println(LabelDetection.detectLabel("toto:"));

        String filename = "src/assembly";
        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {
            int lineNumber = 0;
            String line;
            while ((line = br.readLine()) != null) {

                InstructionController.addLabelsForfirstParcoursForLabels(line, lineNumber + 1);
                lineNumber++;
                // do something to detect which operation and what to do with operands
            }
        } catch (Exception x) {
            x.printStackTrace();
        }

        try (FileReader fr = new FileReader(filename);
             BufferedReader br = new BufferedReader(fr)) {
            int lineNumber = 0;
            String line;
            while ((line = br.readLine()) != null) {
                Optional<String> potentialLabel = LabelDetection.detectLabel(line);
                if (potentialLabel.isEmpty()) {
                    BinaryToHexadecimalOutput.addInstruction(InstructionController.getInstructionBinaryResult(line, lineNumber));
                }
                lineNumber++;
                // do something to detect which operation and what to do with operands
            }
            System.out.println(BinaryToHexadecimalOutput.getOutput());
        } catch (Exception x) {
            x.printStackTrace();
        }

        /*String[] str = Input.getAllPartsOfInstruction("MOVS R7,#5");
        System.out.println(Arrays.toString(str));
        String lineOperator = str[0];
        System.out.println(lineOperator);
        String[] lineOperands = Arrays.copyOfRange(str, 1, str.length);
        System.out.println(Arrays.toString(lineOperands));


        InstructionArgumentsDetection instructionArgumentsDetection = new InstructionArgumentsDetection();
        */

        //System.out.println(instructionDetection.getFullBinaryOfUniqueInstruction(lineOperator, lineOperands));
    }
}
