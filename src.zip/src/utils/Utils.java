package utils;

public class Utils {

    public static boolean argumentsContains(String stringToSearch, String[] argumentsStringArray) {
        for (String str : argumentsStringArray) {
            if (str.contains(stringToSearch)) {
                return true;
            }
        }
        return false;
    }

    public static String convertBinaryValueToFitRightNumberOfBits(String binaryString, int maxSizeOfBinaryValue) {
        if (binaryString.length() == maxSizeOfBinaryValue) {
            return binaryString;
        }
        if (binaryString.length() > maxSizeOfBinaryValue) {
            return binaryString.substring(binaryString.length() - maxSizeOfBinaryValue);
        } else {
            while (binaryString.length() < maxSizeOfBinaryValue) {
                binaryString = "0" + binaryString;
            }
            return binaryString;
        }
    }
}
