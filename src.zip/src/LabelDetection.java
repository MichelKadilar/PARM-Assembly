import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class LabelDetection {

    public static final Map<String, Integer> lineNumberAndAssociatedLabelOfInstruction = new HashMap<>();

    public static void addLabel(int numberOfLine, String label) {
        lineNumberAndAssociatedLabelOfInstruction.put(label, numberOfLine);
    }

    public static Optional<String> detectLabel(String instruction) {
        String trimedInstruction = instruction.trim();
        // We have to do a more complex detection and in which we delete the label of the line and recheck the line
        // this would be useful in case we have a line of that sort : "myLabel: instr r0,#5"
        if (trimedInstruction.matches("^\\w+:$")) {
            return Optional.of(trimedInstruction.substring(0, trimedInstruction.indexOf(":")));
        }
        return Optional.empty();
    }

}
