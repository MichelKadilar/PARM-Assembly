import java.util.Optional;

public enum UniqueInstructionName {

    /*
    Shift, add, sub, move
     */
    LSLS_SASM("00000"),
    LSRS_SASM("00001"),
    ASRS_SASM("00010"),
    ADDS_REGISTER("0001100"),
    SUBS_REGISTER("0001101"),
    ADDS_IMMEDIATE("0001110"),
    SUBS_IMMEDIATE("0001111"),
    MOVS("00100"),
    CMP_SASM("00101"),
    ADDS_OPTIONAL("00110"),
    SUBS_OPTIONAL("00111"),

    /*
    Data processing
     */
    ANDS("0100000000"),
    EORS("0100000001"),
    LSLS_DP("0100000010"),
    LSRS_DP("0100000011"),
    ASRS_DP("0100000100"),

    ADCS("0100000101"),
    SBCS("0100000110"),
    RORS("0100000111"),
    TST("0100001000"),
    RSBS("0100001001"),
    CMP_DP("0100001010"),

    CMN("0100001011"),
    ORRS("0100001100"),
    MULS("0100001101"),
    BICS("0100001110"),
    MVNS("0100001111"),

    /*
    Load/Store
     */
    STR("10010"),
    LDR("10011"),

    /*
    Miscellaneous 16 bit instructions
     */
    ADD("101100000"),
    SUB("101100001");

    final String instructionConstantKnownValue;

    UniqueInstructionName(String contantKnownValue) {
        this.instructionConstantKnownValue = contantKnownValue;
    }

    public static Optional<UniqueInstructionName> getUniqueInstructionIfParameterIsUniqueInstruction(String instructionOperator) {
        String instructionOperatorName = instructionOperator.toUpperCase();
        for (UniqueInstructionName uniqueInstructionName : UniqueInstructionName.values()) {
            if (instructionOperatorName.equals(uniqueInstructionName.name())) {
                return Optional.of(uniqueInstructionName);
            }
        }
        return Optional.empty();
    }
}
